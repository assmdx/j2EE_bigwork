  $.extend(Viewer.prototype, prototype);
