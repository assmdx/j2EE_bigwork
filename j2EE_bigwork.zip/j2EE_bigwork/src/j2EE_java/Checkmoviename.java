package j2EE_java;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import j2EE_java.SaveIntoMysql;

//负责检查电影库中是否已经有要上传的电影
public class Checkmoviename extends HttpServlet {

	public Checkmoviename() {
		super();
	}

	public void destroy() {
		super.destroy();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String str = request.getParameter("moviename1");
		System.out.println("ds asdsafdgf");
		if((new SaveIntoMysql()).checkmovie(str)) {
			response.getWriter().print(true);
		}
		else {
			response.getWriter().print(false);
		}
	}

	public void init() throws ServletException {
	}

}
