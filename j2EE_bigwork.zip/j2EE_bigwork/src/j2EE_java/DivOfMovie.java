package j2EE_java;

public class DivOfMovie {
	private String moviename;
	private String moviePinyin;
	//public String PicName = null;
	public DivOfMovie() { }
	public DivOfMovie(String a,String b) {
		super();
		this.moviename = a;
		this.moviePinyin = b;
		//PicName = c;
	}
	public void setmoviename(String name) {
		this.moviename = name;		
	}
	public void setmoviePinyin(String name) {
		this.moviePinyin = name;		
	}
	public String	getmoviename() {
		return moviename;
	}
	public String	getmoviePinyin() {
		return moviePinyin;
	}
	
	
}
