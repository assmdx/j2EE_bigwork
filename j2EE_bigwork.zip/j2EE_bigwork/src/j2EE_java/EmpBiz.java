package j2EE_java;

import java.util.*;
import java.sql.*;

import j2EE_java.Getconnection;
import j2EE_java.PictureBean;

//实现分页逻辑
public class EmpBiz  {
  public EmpBiz() {

  }

//具体与数据库交互，实现分页的方法，传递两个参数，一个第几页，一个每页的数量
  public PageBean listEmps(int pageNo, int pageCount){
      Connection con = null;
      Statement stmt = null;
      ResultSet rs = null;
      ArrayList emps = new ArrayList();

     //次数我使用mssqlserver的方式，所以计算前后两个范围，用a，b表示
      
      int a = pageNo* pageCount;
      int b = (pageNo-1)* pageCount;
      try {
	   	Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		con = gc.getcon();
		stmt = con.createStatement();
		System.out.println("a=" + a +"b=" + b );
		 rs = stmt.executeQuery("select * from 图片表 limit "+b+", "+a);//???????
		 while(rs.next()) {
		 	PictureBean e = new PictureBean(rs.getString("图片名"),rs.getString("分享日期"),rs.getInt("喜欢"),rs.getString("文件夹名称"));
		 	//System.out.println(rs.getString("图片名")+rs.getString("分享日期")+rs.getInt("喜欢")+rs.getString("文件夹名称"))	;
		 	
		 	//System.out.println("+1");
		 	
		 	emps.add(e);
		 }
		 rs = stmt.executeQuery("select count(*) from 图片表");
		 int totalCount=0;
		 if(rs.next()){
			 totalCount = rs.getInt(1);//???????
		 }   
		 PageBean pageBean = new PageBean(emps,totalCount,pageNo,pageCount);
		 return pageBean;		 	  
      }

      catch (Exception ex) {
        System.out.println("发生错误，错误是:" + ex.getMessage());
        return null;
      } finally {
        if(stmt != null) {
          try { stmt.close(); } catch (SQLException ex1) {}
        }
        if(con != null) {
          try { con.close(); } catch (SQLException ex1) {}
        }
      }
  }
}