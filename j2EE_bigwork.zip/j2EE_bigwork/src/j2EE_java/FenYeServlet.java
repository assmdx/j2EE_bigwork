package j2EE_java;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.util.*;
import j2EE_java.EmpBiz;
;/**
 * Servlet implementation class FenYeServlet
 */
@WebServlet("/FenYeServlet")
public class FenYeServlet extends HttpServlet {


	private static final String CONTENT_TYPE = "text/html; charset=UTF-8";
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FenYeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType(CONTENT_TYPE);
		EmpBiz biz = new EmpBiz();
		//给页数和每页数量一个初始值
		    int pageNo = 1;
		    int pageCount =5;
		    String pageNoStr = request.getParameter("pageNo");
		    String pageCountStr = request.getParameter("pageCount");
		    if(pageNoStr != null){
		      pageNo = Integer.parseInt(pageNoStr);
		    }
		    if(pageCountStr != null){
		      pageCount = Integer.parseInt(pageCountStr);
		    }
		    PageBean pageBean = biz.listEmps(pageNo,pageCount);
		    request.setAttribute("pageBean",pageBean);			    
		    request.getRequestDispatcher("../tps.jsp").forward(request,response);		    		   
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}	
}
