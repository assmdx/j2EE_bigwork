package j2EE_java;

import java.io.IOException;
import java.sql.*;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import j2EE_java.SaveIntoMysql;

//处理用户反馈
public class Fk_servlet extends HttpServlet {
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log

		// Put your code here

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		/*
		Enumeration lists = request.getParameterNames();
		 for(Enumeration e = lists ; e.hasMoreElements(); ) {
			 String thisName = e.nextElement().toString();
			 String thisValue = request.getParameter(thisName);
			 System.out.println(thisName + "-_----------------" + thisValue);
		 }		
		*/
		String fkcontent = request.getParameter("fk_content");
		System.out.println(fkcontent);
		(new SaveIntoMysql()).SaveFk(fkcontent); 
		response.sendRedirect("../index.jsp");
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

}