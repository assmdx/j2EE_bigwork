package j2EE_java;

import java.sql.*;

import j2EE_java.Getconnection;
public class GetDataFromMysql {
	public static ResultSet GetNewMovie(int a,int b) { //查询a~b条数据
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection isLogin = gc.getcon();	
		if(isLogin != null) {
			try {
				PreparedStatement  stmt = isLogin.prepareStatement("select * from 电影表 order by 上映日期 desc  limit  " + a +" , " + b);				
				ResultSet  rs = stmt.executeQuery();
				return rs;
			}catch(Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		else {	return  null;}
	}
	public static ResultSet GetMovieDataByName(String moviename) {
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection isLogin = gc.getcon();	
		if(isLogin != null) {
			try {
				PreparedStatement  stmt = isLogin.prepareStatement("select * from 电影表 where 电影名 = ? ");
				stmt.setString(1,moviename);
				ResultSet  rs = stmt.executeQuery();
				return rs;			
			}catch(Exception e) {
				return null;
			}						
		}
		else {return null;}
	}
	public static ResultSet GetCountryMovieData(String country,int a,int b) {
		String Chinaa = "1_1";
		String Oumei = "1_2";
		String Rihan = "1_3";
		if(Chinaa.equals(country))
			country = new String("中国");
		if(Oumei.equals(country)) 
			country = new String("欧美");
		if(Rihan.equals(country)) 
			country = new String("日韩");		
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection isLogin = gc.getcon();	
		if(isLogin != null) {
			try {
				PreparedStatement  stmt = isLogin.prepareStatement("select * from 电影表 where 国家 = ? order by 上映日期 desc  limit  " + a +" , " + b);		
				stmt.setString(1,country);
				ResultSet  rs = stmt.executeQuery();
				return rs;
			}catch(Exception e) {
				e.printStackTrace();
				return null;				
			}			
		}
		else {return  null;}
	}
	public static ResultSet GetLeibieMovieData(String leibie,int a,int b) {
		//2_1 经典影片  2_2 ......
		String JingDian = "2_1";
		if(JingDian.equals(leibie))
			leibie  = new String("经典影片");
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection isLogin = gc.getcon();	
		if(isLogin != null) {
			try {
				PreparedStatement  stmt = isLogin.prepareStatement("select * from 电影表 where 类别 = ? order by 上映日期 desc  limit  " + a +" , " + b);		
				stmt.setString(1,leibie);
				ResultSet  rs = stmt.executeQuery();
				return rs;
			}catch(Exception e) {
				e.printStackTrace();
				return null;				
			}			
		}
		else {return  null;}
	}
}
