package j2EE_java;

import java.net.FileNameMap;
import java.net.URLConnection;

public class GetMIMEType {
	 public static Boolean  getMimeType(String fileUrl) {		         
		       FileNameMap fileNameMap = URLConnection.getFileNameMap();  
		       String contentype = fileNameMap.getContentTypeFor(fileUrl);
		       //System.out.println(fileUrl + "-------类型:" + contentype);
		       String Str_1 ="image/bmp";
		       String Str_2 ="image/gif";
		       String Str_3 ="image/jpeg";
		       String Str_4 ="image/png";
		       Boolean  ans_str = false;
		      // System.out.println(Str_4.equals(contentype));
		      if(!ans_str && Str_1.equals(contentype)) ans_str = true;
		      if(!ans_str && Str_2.equals(contentype)) ans_str = true;
		      if(!ans_str && Str_3.equals(contentype)) ans_str = true;
		      if(!ans_str && Str_4.equals(contentype)) ans_str = true;
		       return ans_str;		       		        
	 }
}
