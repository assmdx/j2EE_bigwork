package j2EE_java;//连接数据库

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Getconnection {
	public Connection conn = null;
	public  boolean getConnection(String name,String pwd){
	   String driver = "com.mysql.jdbc.Driver";
	   String dbName ="j2ee_bwdata";
	   try {
		   Class.forName(driver).newInstance();
	    try {
	    	String username = "root";
	    	String userPasswd ="";
	    	String url = "jdbc:mysql://localhost/"+dbName +"?useUnicode=true&characterEncoding=UTF-8";
	    	conn = DriverManager.getConnection(url,username,userPasswd);
	    } catch (SQLException e) {
	     e.printStackTrace();
	     return false;
	    }
	   } catch (Exception e) {
	    e.printStackTrace();
	    return false;
	   }
	   System.out.println("�ѻ����ݿ������");
	   return true;
	}
	
	public Connection getcon() {
		return conn;
	}
	public void stopconn() {
		try {
			conn.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
}