package j2EE_java;

import java.io.*;

public class JavaMakeJsp extends Thread {
	String path  = null;
	String filename =  null;	 
	public void run()  { //传进来的是路径,文件名称
		try{
			OutputStream out1 =  new FileOutputStream(new File(path,filename)); 
			InputStream in = new FileInputStream(new File("F:\\Tomcat\\apache-tomcat-8.0.29\\webapps\\j2EE_bigwork\\TemplateImgJsp.jsp"));
			 int length = 0 ;  
			 byte [] buf = new byte[1024] ;               
			 while( (length = in.read(buf) ) != -1)  
			 {  
				 out1.write(buf, 0, length);                 
			 }                 
			 in.close();  
			 out1.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public   JavaMakeJsp(String a,String b) {
		path = a;
		path += "\\jspppp";
		File parentFileDir = new File(path);	 
	        if (!parentFileDir.exists()) {
	            parentFileDir.mkdirs();
	        }
		filename =b;
	}
	
	
}
