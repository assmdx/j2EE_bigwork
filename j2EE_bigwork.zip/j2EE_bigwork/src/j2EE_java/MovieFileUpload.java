package j2EE_java;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.util.List;
import java.util.Date;
import java.util.Enumeration;
import java.net.FileNameMap;
import java.net.URLConnection;

import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;  
import org.apache.commons.fileupload.disk.DiskFileItemFactory;  
import org.apache.commons.fileupload.servlet.ServletFileUpload; 
import org.apache.commons.io.FileUtils;


import j2EE_java.SaveIntoMysql;
import j2EE_java.ImageUtils;
import j2EE_java.GetMIMEType;
import j2EE_java.JavaMakeMovieJsp;

/**
 * Servlet implementation class PictureUpload
 */
@WebServlet("/MovieFileUpload")
public class MovieFileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MovieFileUpload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		fileUpload(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		fileUpload(request,response);
	}
	public void fileUpload(HttpServletRequest request,HttpServletResponse response) throws ServletException {
		//文件存储目录的定义
		String path = "..\\webapps\\j2EE_bigwork\\SaveMovieHere\\temp";//缓存文件的存储路径
		String pathofmovie = "..\\webapps\\j2EE_bigwork\\SaveMovieHere\\movie";//存文件的路径
		File parentFileDir = new File(path);	 
        if (!parentFileDir.exists()) {
            parentFileDir.mkdirs();
        }
        File parentFileDirr = new File(pathofmovie);	 
        if (!parentFileDirr.exists()) {
            parentFileDirr.mkdirs();
        }
        int chunks = -1;
  		int chunk = -1;
        
        //获取上传文件的各项参数
		 try { 			 
			 if(request.getParameter("chunks") == null) {}
			 else chunks = Integer.parseInt(request.getParameter("chunks"));
			 if(request.getParameter("chunk") == null) {}
			 else chunk = Integer.parseInt(request.getParameter("chunk"));
			 String moviename = request.getParameter("movieName");
			 String moviePinyin = request.getParameter("movieNamePinyin");
			 String moviecountry = request.getParameter("country");
			 String movieType = request.getParameter("movieType");
			 String SyTime = request.getParameter("SyTime");
			 String summary = request.getParameter("summary");
			 String downloadAddress =request.getParameter("downloadAddress");				
			 new SaveIntoMysql().SaveMovie(new moviecontent(moviename,moviecountry,movieType,SyTime,summary,downloadAddress,moviePinyin));
			 makeNullMovieNameFile(pathofmovie + "\\" +  moviePinyin ,moviename);
			 //写入磁盘			
			 if(chunks == -1) {
				 String filename = request.getParameter("name");
				 InputStream in = request.getInputStream();
				 //String truefilename = pathofmovie + "\\" + moviename + "_";
				 String truefilename = pathofmovie + "\\" + moviePinyin;						 
				 if(!(new File(truefilename)).exists()) {
					 (new File(truefilename)).mkdirs();
				 }
				 truefilename = truefilename + "\\" + filename;
				 OutputStream out =  new FileOutputStream(new File(truefilename)); 
				 int length = 0 ;  
				     byte [] buf = new byte[1024] ;               
				     while( (length = in.read(buf) ) != -1)  
				     {  
				         out.write(buf, 0, length);                 
				     }                 
				     in.close();  
				     out.close();		
				     makeThumbail(pathofmovie,moviePinyin); //生成缩略图				  						 
			 }
			 else {
				 String filename = request.getParameter("name");
				 InputStream in = request.getInputStream();
				 String filetempname = filename + "_" + String.valueOf(chunk) + ".part";
				 String pathnow = path + "\\" + filename;
				 if(!(new File(pathnow)).exists()) {
					 new File(pathnow).mkdirs();
				 }				 
				 OutputStream out =  new FileOutputStream(new File(pathnow,filetempname));  
				 int length = 0 ;  
			         byte [] buf = new byte[1024] ;               
			         while( (length = in.read(buf) ) != -1)  
			          {  
			        	 out.write(buf, 0, length);                 
			          }                 
			         in.close();  
			         out.close();
	             
				 
				 
	             //检查是否所有分片均接收完毕
	             boolean ans = true ;
				 for(int i = 0; i < chunks ;i++) {
					 String filenowtempname = pathnow + "\\" +filename + "_" + String.valueOf(i) + ".part";
					 if(!(new File(filenowtempname)).exists()) 
						 ans = false;
				 }
				 if(ans) {					 			
					 String truefilename = pathofmovie + "\\" + moviePinyin;						
					 if(!(new File(truefilename)).exists()) {
						 (new File(truefilename)).mkdirs();
					 }
					 truefilename = truefilename + "\\" + filename;
					 OutputStream nowout =  new FileOutputStream(new File(truefilename));
					 for(int i = 0; i < chunks ; i++) {
						 //将所有分片拼成一片，写到磁盘上？？？？？？？？图片怎么处理？？？？？
						 String filenowtempname = path + "\\"+ filename +"\\"+filename + "_" + String.valueOf(i) + ".part";
						 InputStream innow = new FileInputStream(new File(filenowtempname));
						 int lengthh = 0 ;  
					             byte [] buff = new byte[1024] ;               
					             while( (lengthh = innow.read(buff) ) != -1)  
					             {  
					                 nowout.write(buff, 0, lengthh);			                 
					             }                 
					             innow.close();  
					             (new File(filenowtempname)).delete();
					 }
					 String pieceTempName =path + "\\" + filename; 
					 (new File(pieceTempName)).delete();
					 nowout.close();	
					 makeThumbail(pathofmovie,moviePinyin); //生成缩略图					 	 					
				 }
			 }           
		 } catch(Exception e) {
			 e.printStackTrace();
		 }
    }	
	
	 
	 //生成缩略图	 
	 private void makeThumbail(String pathofmovie_1,String moviePinyin_1)  {
		   //生成缩略图.
		 try {
			 String PathForImg = pathofmovie_1 +"\\"  + moviePinyin_1;
			 if(!((new File(PathForImg+"\\Thumbnail")).exists())) {
				 File pathForimg = new File(PathForImg);
				 File [] files = pathForimg.listFiles();
				  for(File a:files) {      	      								      								     
					  	if(a.isDirectory()){   } 							  				    							  													     
					        else { 
					        	//System.out.println(a.getName() + "......................."+a.getAbsolutePath());							        	
					      		if(GetMIMEType.getMimeType(a.getAbsolutePath())) {
					      			//System.out.println("要生成缩略图的文件:"+a.getName());
					      			ImageUtils.ImageToMini(PathForImg, a.getName(),480);					      			
					      			break;
					      		}
					        }   							  			
				  }
				  new Thread(new JavaMakeMovieJsp(pathofmovie_1 + "\\" + moviePinyin_1,moviePinyin_1 + ".jsp")).start();
			 }
		 }catch(Exception e) {
			 e.printStackTrace();
		 }
		 			
	 }
	 //在电影文件夹下新建一个空文件夹，名字是电影名，以便后面单个电影jsp提取信息
	 public void makeNullMovieNameFile(String pathofmovie_2,String moviename_1) {
		 String pathofnullfile = pathofmovie_2 + "\\" + moviename_1;
		 File pathofnullfile_1 = new File(pathofnullfile);
		 if(!pathofnullfile_1.exists()) {
			 pathofnullfile_1.mkdirs();
		 }
	 }
}