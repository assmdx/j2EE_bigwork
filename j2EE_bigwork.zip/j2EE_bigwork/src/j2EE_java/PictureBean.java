package j2EE_java;

public class PictureBean {	
	String pictureName = null;
	String datetime = null;
	int like;
	String pictureFileName = null;
	public PictureBean(String a,String b,int c,String d) {
		pictureName  = a;
		datetime = b;
		like = c;
		pictureFileName = d;
	}
	public PictureBean() {
		
	}
	public String getpictureName() {
		return pictureName;
	}
	public String getdatetime() {
		return datetime;
	}
	public int getlike() {
		return like;
	}
	public String getpictureFileName() {
		return pictureFileName;
	}
}
