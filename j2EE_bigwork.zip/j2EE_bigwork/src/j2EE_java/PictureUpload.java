package j2EE_java;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.util.List;
import java.util.Date;
import java.util.Enumeration;


import j2EE_java.SaveIntoMysql;
import j2EE_java.ImageUtils;
import j2EE_java.JavaMakeJsp;
/**
 * Servlet implementation class PictureUpload
 */
@WebServlet("/PictureUpload")
public class PictureUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PictureUpload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		fileUpload(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		fileUpload(request,response);
	}
	public String StringFormat(String aa) {
		String b = "/";
		String c ="：";
		String d = aa.replaceAll(b, "");
		String e = d.replaceAll(c,"");
		return e;
	}
	public void fileUpload(HttpServletRequest request,HttpServletResponse response) throws ServletException {
		String path = "..\\webapps\\j2EE_bigwork\\SaveMovieHere\\picture";//图片文件的存储路径
		File parentFileDir = new File(path);
		 System.out.println(parentFileDir.getAbsolutePath());
        if (!parentFileDir.exists()) {
            parentFileDir.mkdirs();
        }
        String FileDirName = StringFormat(request.getParameter("filedirname"));
		 try { 
		 	 Enumeration lists = request.getParameterNames();
		 	 String imagetitles = null;
			 for(Enumeration e = lists ; e.hasMoreElements(); ) {
				 String thisName = e.nextElement().toString();
				 String thisValue = request.getParameter(thisName);
				 System.out.println(thisName + "-_----------------" + thisValue);
				 //提取上传文件的参数
				 imagetitles = request.getParameter("uid"); //图片的标题
				 
				 //String imagname =  request.getParameter("name");
			 }
			 
			 
			 String filename = request.getParameter("name");
			 InputStream in = request.getInputStream();
			 String pathnow = path + "\\" + FileDirName;           //真正的路径
			 boolean anss = true;					//图片文件夹下是否已经有缩略图
			 if(!(new File(pathnow)).exists()) {
				 new File(pathnow).mkdirs();
				 anss = false;							//改变anss
			 }
			 OutputStream out =  new FileOutputStream(new File(pathnow,filename));  
			 int length = 0 ;  
		             byte [] buf = new byte[1024] ;               
		             while( (length = in.read(buf) ) != -1)  
		             {  
		                 out.write(buf, 0, length);                 
		             }                 
		             in.close();  
		             out.close();  
		            (new SaveIntoMysql()).SaveImg(imagetitles,FileDirName);
		            if(!anss) {
		            		ImageUtils.ImageToMini(pathnow, filename,160);
		            		new Thread(new JavaMakeJsp(pathnow,FileDirName + ".jsp")).start();//生成该展示该图片集的jsp文件
		            }
		 } catch(Exception e) {
			 e.printStackTrace();
		 }
    }
}