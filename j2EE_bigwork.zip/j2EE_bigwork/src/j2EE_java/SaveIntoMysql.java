package j2EE_java;			

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import j2EE_java.Getconnection;
import j2EE_java.moviecontent;

//与数据库交互，主要负责存信息
public class SaveIntoMysql {
	public void SaveImg(String ImgTitle,String FileDirAddress) {
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection gccon = gc.getcon();
		if (gccon != null) {
			try{
		    	CallableStatement  stmt = gccon.prepareCall("{call SaveImg(?,?)}");
		    	stmt.setString(1,ImgTitle);
		    	stmt.setString(2,FileDirAddress);
		    	stmt.execute();
		    	stmt.close();
		    	gc.stopconn();
		    }catch(Exception e) {
		    	e.printStackTrace();
		    }
		} 
	}
	public void SaveFk(String fkcontent) {
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection gccon = gc.getcon();
		if (gccon != null) {
			try{
				CallableStatement  stmt = gccon.prepareCall("{call SaveFk(?)}");
		    	stmt.setString(1,fkcontent);	
		    	stmt.execute();
		    	stmt.close();
		    	gc.stopconn();
		    }catch(Exception e) {
		    	e.printStackTrace();
		    }
		} 
	}
	public void SaveMovie(moviecontent MC) {
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection gccon = gc.getcon();
		if (gccon != null) {
			try{
				CallableStatement  stmt = gccon.prepareCall("{call SaveMovie(?,?,?,?,?,?,?)}");
		    	stmt.setString(1,MC.Moviename);
		    	stmt.setString(2,MC.country);
		    	stmt.setString(3,MC.type);
		    	stmt.setString(4,MC.time);
		    	stmt.setString(5,MC.summary);
		    	stmt.setString(6,MC.downaddress);
		    	stmt.setString(7,MC.moviePinyin);
		    	stmt.execute();
		    	stmt.close();
		    	gc.stopconn();
		    }catch(Exception e) {
		    	e.printStackTrace();
		    }
		} 
	}
	public boolean checkmovie(String str) {
		boolean ans = false;
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection gccon = gc.getcon();
		if (gccon != null) {
			try{
				CallableStatement  stmt = gccon.prepareCall("{call  CheckMovieName(?)}");
		    	stmt.setString(1,str);
		    	stmt.execute();		    	
		    	ResultSet x = (ResultSet)stmt.executeQuery();
		    	if(x.next()) {
		    		ans = true; 
		    	}
		    	stmt.close();
		    	gc.stopconn();
		    }catch(Exception e) {
		    	e.printStackTrace();
		    }
		} 
		return ans;
	}
}