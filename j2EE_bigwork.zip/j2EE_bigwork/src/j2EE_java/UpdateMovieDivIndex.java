package j2EE_java;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import j2EE_java.GetDataFromMysql;
import j2EE_java.GetMIMEType;
import j2EE_java.DivOfMovie;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.*;
import java.io.File;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


/**
 * Servlet implementation class UpdateMovieDivIndex
 */
@WebServlet("/UpdateMovieDivIndex")
public class UpdateMovieDivIndex extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateMovieDivIndex() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub		
		int pageid = Integer.parseInt(request.getParameter("pageid"));		
		int num =Integer.parseInt(request.getParameter("Num"));						
		try {
			ResultSet rs = null;
			switch(pageid) {
				case 0:	rs = GetDataFromMysql.GetNewMovie(num+1, num+20); break;
				case 1:	rs = GetDataFromMysql.GetNewMovie(num+1,num+ 20); break;
				case 2:	rs = GetDataFromMysql.GetCountryMovieData("1_1",num+1, num+20);	 break;
				case 3:	rs = GetDataFromMysql.GetCountryMovieData("1_2",num+1, num+20); break;
				case 4:	rs = GetDataFromMysql.GetCountryMovieData("1_3",num+1, num+20); break;
				case 5:	rs = GetDataFromMysql.GetLeibieMovieData("2_1",num+1, num+20); break;		
			}			
			List<DivOfMovie> list = new ArrayList<DivOfMovie>();	
			int count_rs = 0;
			while(rs.next()) {
				DivOfMovie div = new DivOfMovie(rs.getString(7),rs.getString(8));
				list.add(div);
				count_rs++;
			}
			JSONArray ja = JSONArray.fromObject(list);				
			System.out.println(ja.toString());
			if(count_rs > 0)
				response.getWriter().print(ja.toString());
			else 
				response.getWriter().print("null");
		}catch(Exception e) {
			e.printStackTrace();
		}								
	}	
}
