package j2EE_java;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import j2EE_java.Getconnection;

public class login_servlet extends HttpServlet {
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log

		// Put your code here

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		String uuname = new String(request.getParameter("invitenumber").getBytes(
				"UTF-8"), "UTF-8");
		if(uuname == null) {
			System.out.println("�˴�������");
		}
		Getconnection gc = new Getconnection();
		gc.getConnection("1","2");
		Connection isLogin = gc.getcon();
		
		if (isLogin != null) {
			boolean ans = false;
			try{
		    	CallableStatement  stmt = isLogin.prepareCall("{call loginyz(?)}");
		    	stmt.setString(1,uuname);
		    	stmt.execute();
		    	ResultSet x = (ResultSet)stmt.executeQuery();
		    	if(x.next()) {
		    		ans = true; 
		    	}
		    	x.close();
		    	stmt.close();
		    	gc.stopconn();
		    }catch(Exception e) {
		    	e.printStackTrace();
		    }
			if(ans == true) {
				response.sendRedirect("../fbdy.jsp");
			}
			else {
				response.sendRedirect("../login.jsp?message=loginfailed");
			}
		} 
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

}