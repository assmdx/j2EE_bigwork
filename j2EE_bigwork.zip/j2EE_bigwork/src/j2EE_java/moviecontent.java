package j2EE_java;

public class moviecontent {
	String Moviename;
	String country;
	String type;
	String time;
	String summary;
	String downaddress;
	String moviePinyin;
	moviecontent(String a,String b,String c,String d,String e,String f,String g) {
		Moviename = a;
		country = b;
		type = c;
		time = d;
		summary = e;
		downaddress = f;		
		moviePinyin = g;
	}
}