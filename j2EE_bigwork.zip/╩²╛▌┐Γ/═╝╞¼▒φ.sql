﻿create table 图片表(
       图片名 varchar(100),
       文件夹名称 varchar(200) primary key,
       分享日期 datetime,
       喜欢 int       
);