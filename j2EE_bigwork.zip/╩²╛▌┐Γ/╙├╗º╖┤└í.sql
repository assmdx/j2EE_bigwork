﻿create table 用户反馈 (
 内容 text,
 时间 datetime
);