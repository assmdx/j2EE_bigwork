﻿create procedure SaveImg(in title varchar(100),in fileDirAddress varchar(200)) 
begin
insert ignore 
into
图片表
values(title,now(),0,fileDirAddress);
end;
