﻿
create procedure SaveFk(in nu text)
begin
insert into 用户反馈
values(nu,now());
end;
