﻿create table 求片表(
       片名 varchar(100),
       求片日期 datetime
);