﻿create table 电影表(
       电影名 varchar(50),
       上映日期  date,
       网站发布日期 date,
       国家 varchar(50),
       类别 varchar(30),
       简介 text,
       下载地址 text ,
	拼音 varchar(100)      
);

alter table 电影表
add column 拼音 varchar(100);