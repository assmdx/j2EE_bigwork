﻿create procedure loginyz(in nu varchar(30))
begin
select *
from 邀请码
where number = nu;
end;
