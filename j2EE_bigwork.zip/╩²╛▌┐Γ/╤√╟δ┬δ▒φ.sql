﻿create table 邀请码(
       number varchar(30)
);