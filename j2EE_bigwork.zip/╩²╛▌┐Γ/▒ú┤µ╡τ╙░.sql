﻿create procedure SaveMovie(in moviename varchar(50),in country varchar(50),in movietype varchar(30),in Sytime varchar(50) ,in summary text,in daddress text,in moviepinyin varchar(100))
begin
insert ignore
into 电影表
values(Sytime,now(),country,movietype,summary,daddress,moviename,moviepinyin);
end;
